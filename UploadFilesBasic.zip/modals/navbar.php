<?php if(!isset($connection)) die('<title>Access Denied</title><i>This page cannot be accessed directly</i>'); ?>
<div id="navbar" class="col-sm-12 col-md-12">

 <div class="navbar navbar-default visible-sml">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#sideNavbar">
        <span class="glyphicon glyphicon-align-justify"></span>                    
      </button>
      <a class="navbar-brand" href="javascript:void(0)"><?php echo SiteName();?></a>
    </div>

  </div>
</div>
</div>