<?php if(!isset($connection)) die('<title>Access Denied</title><i>This page cannot be accessed directly</i>'); ?>

<h2><?php echo $lang[275] ?> : </h2> <!--<?php echo Get_Domain(siteurl) ?> -->
<?php echo $lang[273] ?> : 
<a href ="<?php echo siteurl ?>/?profile"><?php echo siteurl ?>/?profile</a>
<h2><?php echo $lang[274] ?> : </h2>
<div class="table-responsive top20 <?php echo ClassAnimated ?> swing">
<table class="table table-bordered">
    <thead>
      <tr>
        <th><?php echo $lang[255] ?></th>
        <th><?php echo $lang[277] ?></th>
        <th><?php echo $lang[132] ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>uploadfile</td>
        <td><?php echo IntToIcon('1') ?></td>
        <td><?php echo $lang[36] ?></td>
      </tr>
      <tr>
        <td>passwordfile</td>
        <td><?php echo IntToIcon('1') ?></td>
        <td><?php echo $lang[37] ?></td>
      </tr>
      <tr>
        <td>ispublic</td>
        <td><?php echo IntToIcon('1') ?></td>
        <td><?php echo $lang[176] ?></td>
      </tr>
	   <tr>
        <td>api</td>
        <td><?php echo IntToIcon('0') ?></td>
        <td><?php echo $lang[275] ?></td>
      </tr>
	   <tr>
        <td>username</td>
        <td><?php echo IntToIcon('0') ?></td>
        <td><?php echo $lang[35] ?></td>
      </tr>
    </tbody>
  </table>
 </div>
<!-- HTML generated using hilite.me -->
<pre dir="ltr" style="margin: 0; line-height: 125% ;">  <span style="color: #204a87; font-weight: bold">function</span> <span style="color: #000000">UploadFile</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #000000">Sfile</span><span style="color: #ce5c00; font-weight: bold">:</span><span style="color: #204a87; font-weight: bold">string</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">:</span><span style="color: #204a87; font-weight: bold">string</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #8f5902; font-style: italic">{</span>
<span style="color: #8f5902; font-style: italic">const</span>
<span style="color: #8f5902; font-style: italic">BaseUrl =&#39;<?php echo defined('siteurl') ? siteurl :'http://127.0.0.1/AjaxUploader' ?>&#39;;</span>
<span style="color: #8f5902; font-style: italic">userName = &#39;<?php echo defined('UserName') ? UserName : 'UserName' ?>&#39; ;</span>
<span style="color: #8f5902; font-style: italic">apikey = &#39;<?php echo defined('UserEmail') ? clean(Encrypt(TwoWayEncrypt(UserEmail,RegisterDate))) : 'cHFcHhYd3R2eX07cXZ7' ?>&#39;  ;   }</span>
<span style="color: #204a87; font-weight: bold">var</span>
    <span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">:</span> <span style="color: #000000">TIdMultipartFormDataStream</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #204a87; font-weight: bold">begin</span>
<span style="color: #000000">BaseUrl</span> <span style="color: #ce5c00; font-weight: bold">:=</span> <span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Edit1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Text</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">userName</span> <span style="color: #ce5c00; font-weight: bold">:=</span> <span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Edit2</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Text</span> <span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">apikey</span> <span style="color: #ce5c00; font-weight: bold">:=</span> <span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Edit3</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Text</span>  <span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Cursor</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #000000">crHourGlass</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Label1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Caption</span> <span style="color: #ce5c00; font-weight: bold">:=</span> <span style="color: #4e9a06">&#39;&#39;</span><span style="color: #ce5c00; font-weight: bold">;</span>

<span style="color: #204a87; font-weight: bold">try</span>
<span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #000000">TIdMultiPartFormDataStream</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Create</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">AddFile</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #4e9a06">&#39;uploadfile&#39;</span><span style="color: #ce5c00; font-weight: bold">,</span><span style="color: #204a87; font-weight: bold">pchar</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #000000">Sfile</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">,</span><span style="color: #4e9a06">&#39;multipart/form-data&#39;</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">AddFormField</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #4e9a06">&#39;passwordfile&#39;</span><span style="color: #ce5c00; font-weight: bold">,</span><span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Edit4</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Text</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">AddFormField</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #4e9a06">&#39;ispublic&#39;</span><span style="color: #ce5c00; font-weight: bold">,</span><span style="color: #204a87">IntToStr</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #204a87; font-weight: bold">Integer</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">CheckBox1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Checked</span><span style="color: #000000; font-weight: bold">)))</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">IdHTTP1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Request</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">CustomHeaders</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Clear</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">IdHTTP1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Request</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">UserAgent</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #4e9a06">&#39;Mozilla/5.0 (Windows NT 6.1; rv:54.0) Gecko/20100101 Firefox/54.0&#39;</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">IdHTTP1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Request</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">CustomHeaders</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Add</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #4e9a06">&#39;X-Requested-With: XMLHttpRequest&#39;</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">;</span>


<span style="color: #204a87; font-weight: bold">try</span>
<span style="color: #3465a4">result</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Idhttp1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">post</span><span style="color: #000000; font-weight: bold">(</span><span style="color: #000000">BaseUrl</span><span style="color: #ce5c00; font-weight: bold">+</span><span style="color: #4e9a06">&#39;/ajax/index.php?uploadfile&amp;api=&#39;</span><span style="color: #ce5c00; font-weight: bold">+</span><span style="color: #000000">apikey</span><span style="color: #ce5c00; font-weight: bold">+</span><span style="color: #4e9a06">&#39;=&amp;username=&#39;</span><span style="color: #ce5c00; font-weight: bold">+</span><span style="color: #000000">userName</span><span style="color: #ce5c00; font-weight: bold">,</span><span style="color: #000000">Params</span><span style="color: #000000; font-weight: bold">)</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #204a87; font-weight: bold">except</span>
 <span style="color: #3465a4">result</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #4e9a06">&#39;{&quot;success&quot;:false,&quot;msg&quot;:&quot;Server not responding&quot;}&#39;</span><span style="color: #ce5c00; font-weight: bold">;</span>
 <span style="color: #8f5902; font-style: italic">//on E : Exception do ShowMessage(E.ClassName+&#39; error raised, with message : &#39;+E.Message);</span>
<span style="color: #204a87; font-weight: bold">end</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #204a87; font-weight: bold">Finally</span>
  <span style="color: #000000">Params</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Free</span>  <span style="color: #ce5c00; font-weight: bold">;</span>
  <span style="color: #000000">form1</span><span style="color: #ce5c00; font-weight: bold">.</span><span style="color: #000000">Cursor</span><span style="color: #ce5c00; font-weight: bold">:=</span><span style="color: #000000">crDefault</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #204a87; font-weight: bold">end</span><span style="color: #ce5c00; font-weight: bold">;</span>
<span style="color: #204a87; font-weight: bold">end</span><span style="color: #ce5c00; font-weight: bold">;</span>
</pre>

<h2><?php echo $lang[276] ?> : </h2>

<!-- HTML generated using hilite.me -->
<pre dir="ltr" style="margin: 0; line-height: 125%"><span style="color: #000000; font-weight: bold">{</span>
   <span style="color: #204a87; font-weight: bold">&quot;success&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #204a87; font-weight: bold">true</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;FileName&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;file_2018-08-11_081735.jpg&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;originalFilename&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;sample.jpg&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;Icon&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;icon-file-image&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;Size&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #0000cf; font-weight: bold">7324</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;SavedFile&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;..\/uploads\/file_2018-08-11_081735.jpg&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;Extension&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;jpg&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;DeleteId&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;kQ8fQjVW6a&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;DownloadId&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;uz2y1v0L8a&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;ID&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #0000cf; font-weight: bold">854</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;cryptID&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;ODU0&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;UploadDir&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;\/uploads&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;ThumbnailDir&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;\/uploads\/_thumbnail\/d7e1d8ec7eb1928ec9d4aa537ee2600e.jpg&quot;</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;IsLogin&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #204a87; font-weight: bold">false</span><span style="color: #000000; font-weight: bold">,</span>
   <span style="color: #204a87; font-weight: bold">&quot;footerInfo&quot;</span><span style="color: #000000; font-weight: bold">:</span><span style="color: #4e9a06">&quot;Copyright © 2018. All rights reserved ( onexite ).&quot;</span>
<span style="color: #000000; font-weight: bold">}</span>
</pre>
<br>
