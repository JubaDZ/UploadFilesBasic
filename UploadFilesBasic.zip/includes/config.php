<?php
define('dbhost','localhost'); 
define('dbuser','root'); 
define('dbpass',''); 
define('dbname','db_uploads'); 

define('StatsPanel',true); //false-true
define('TotalStats',false); // home page  Require ApiStatus 
define('OutputImage',true); //forceView
define('EnableLogo',false);
define('UpdateBrowser',true); // ie8=< message
define('DirectoryChanged',false);

$supportedLangs  = array('ar','en','') ;
$_plans          = array('0'=>'free','1'=>'premium','2'=>'gold','3'=>'register');
/*define('MainTitle','اكتب هنا اسم موقعك');*/
?>