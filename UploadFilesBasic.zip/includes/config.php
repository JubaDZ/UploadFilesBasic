<?php
define('dbhost','localhost'); 
define('dbuser','root'); 
define('dbpass',''); 
define('dbname','db_uploads'); 

define('FooterInfo',true); //false-true
define('EnableLogo',true);
define('UpdateBrowser',true); // ie8=< message
define('DirectoryChanged',true);
define('ApiStatus',true);

define('MainTitle','اكتب هنا اسم موقعك');
$supportedLangs  = array('ar','en','') ;
$_plans          = array('0'=>'free','1'=>'premium','2'=>'gold','3'=>'register');
$currentpage     = 1 ;
$totalpages      = 1 ;
?>